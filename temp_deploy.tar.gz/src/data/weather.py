"""Weather ensemble forecast fetching from Open-Meteo Ensemble API (free, 31-member GFS)."""
import logging
import statistics
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional

import requests

logger = logging.getLogger("nachomarket.data.weather")

CITY_CONFIG: Dict[str, dict] = {
    "nyc": {
        "name": "New York City",
        "lat": 40.7128,
        "lon": -74.0060,
        "nws_station": "KNYC",
    },
    "chicago": {
        "name": "Chicago",
        "lat": 41.8781,
        "lon": -87.6298,
        "nws_station": "KORD",
    },
    "miami": {
        "name": "Miami",
        "lat": 25.7617,
        "lon": -80.1918,
        "nws_station": "KMIA",
    },
    "los_angeles": {
        "name": "Los Angeles",
        "lat": 34.0522,
        "lon": -118.2437,
        "nws_station": "KLAX",
    },
    "denver": {
        "name": "Denver",
        "lat": 39.7392,
        "lon": -104.9903,
        "nws_station": "KDEN",
    },
}

CITY_ALIASES: Dict[str, str] = {
    "new york": "nyc",
    "nyc": "nyc",
    "new york city": "nyc",
    "chicago": "chicago",
    "miami": "miami",
    "los angeles": "los_angeles",
    "la": "los_angeles",
    "denver": "denver",
}

MONTH_MAP: Dict[str, int] = {
    "january": 1, "february": 2, "march": 3, "april": 4,
    "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
    "jan": 1, "feb": 2, "mar": 3, "apr": 4,
    "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


@dataclass
class EnsembleForecast:
    """Ensemble weather forecast with per-member temperature data."""

    city_key: str
    city_name: str
    target_date: date
    member_highs: List[float]
    member_lows: List[float]
    mean_high: float = 0.0
    std_high: float = 0.0
    mean_low: float = 0.0
    std_low: float = 0.0
    num_members: int = 0
    fetched_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        if self.member_highs:
            self.mean_high = statistics.mean(self.member_highs)
            self.std_high = (
                statistics.stdev(self.member_highs)
                if len(self.member_highs) > 1
                else 0.0
            )
            self.num_members = len(self.member_highs)
        if self.member_lows:
            self.mean_low = statistics.mean(self.member_lows)
            self.std_low = (
                statistics.stdev(self.member_lows)
                if len(self.member_lows) > 1
                else 0.0
            )

    def probability_high_above(self, threshold_f: float) -> float:
        """Fraccion de miembros con temperatura maxima > threshold."""
        if not self.member_highs:
            return 0.5
        count = sum(1 for h in self.member_highs if h > threshold_f)
        return count / len(self.member_highs)

    def probability_high_below(self, threshold_f: float) -> float:
        """Fraccion de miembros con temperatura maxima < threshold."""
        return 1.0 - self.probability_high_above(threshold_f)

    def probability_low_above(self, threshold_f: float) -> float:
        """Fraccion de miembros con temperatura minima > threshold."""
        if not self.member_lows:
            return 0.5
        count = sum(1 for l in self.member_lows if l > threshold_f)
        return count / len(self.member_lows)

    def probability_low_below(self, threshold_f: float) -> float:
        """Fraccion de miembros con temperatura minima < threshold."""
        return 1.0 - self.probability_low_above(threshold_f)

    @property
    def ensemble_agreement(self) -> float:
        """Que tan unilateral es el ensemble (0.5 = dividido, 1.0 = unanime)."""
        if not self.member_highs:
            return 0.5
        median = statistics.median(self.member_highs)
        above = sum(1 for h in self.member_highs if h > median)
        frac = above / len(self.member_highs)
        return max(frac, 1.0 - frac)


# Cache: (city_key, target_date_str) -> (timestamp, EnsembleForecast)
_forecast_cache: Dict[str, tuple[float, "EnsembleForecast"]] = {}
_CACHE_TTL = 900  # 15 minutos


def _celsius_to_fahrenheit(c: float) -> float:
    return c * 9.0 / 5.0 + 32.0


def fetch_ensemble_forecast(
    city_key: str, target_date: Optional[date] = None
) -> Optional["EnsembleForecast"]:
    """Obtiene forecast del ensemble GFS (31 miembros) desde Open-Meteo.

    Args:
        city_key: Clave de ciudad en CITY_CONFIG (nyc, chicago, miami, etc.)
        target_date: Fecha objetivo. Default: hoy.

    Returns:
        EnsembleForecast con temperaturas max/min por miembro, o None si falla.
    """
    if city_key not in CITY_CONFIG:
        logger.warning(f"Unknown city key: {city_key}")
        return None

    if target_date is None:
        target_date = date.today()

    cache_key = f"{city_key}_{target_date.isoformat()}"
    now = time.time()
    if cache_key in _forecast_cache:
        cached_time, cached_forecast = _forecast_cache[cache_key]
        if now - cached_time < _CACHE_TTL:
            return cached_forecast

    city = CITY_CONFIG[city_key]

    try:
        params = {
            "latitude": city["lat"],
            "longitude": city["lon"],
            "daily": "temperature_2m_max,temperature_2m_min",
            "temperature_unit": "fahrenheit",
            "start_date": target_date.isoformat(),
            "end_date": target_date.isoformat(),
            "models": "gfs_seamless",
        }

        response = requests.get(
            "https://ensemble-api.open-meteo.com/v1/ensemble",
            params=params,
            timeout=15.0,
        )
        response.raise_for_status()
        data = response.json()

        daily = data.get("daily", {})

        # Open-Meteo devuelve cada miembro como clave separada:
        #   temperature_2m_max (control), temperature_2m_max_member01, ..., _member30
        member_highs: list[float] = []
        member_lows: list[float] = []

        for key, values in daily.items():
            if not isinstance(values, list) or not values:
                continue
            val = values[0]
            if val is None:
                continue
            if "temperature_2m_max" in key:
                member_highs.append(float(val))
            elif "temperature_2m_min" in key:
                member_lows.append(float(val))

        if not member_highs:
            logger.warning(f"No ensemble data for {city_key} on {target_date}")
            return None

        forecast = EnsembleForecast(
            city_key=city_key,
            city_name=city["name"],
            target_date=target_date,
            member_highs=member_highs,
            member_lows=member_lows,
        )

        _forecast_cache[cache_key] = (now, forecast)
        logger.info(
            "Ensemble forecast for %s on %s: High %.1fF +/- %.1fF (%d members)",
            city["name"],
            target_date,
            forecast.mean_high,
            forecast.std_high,
            forecast.num_members,
        )

        return forecast

    except Exception as e:
        logger.warning(f"Failed to fetch ensemble forecast for {city_key}: {e}")
        return None


def fetch_nws_observed_temperature(
    city_key: str, target_date: Optional[date] = None
) -> Optional[Dict[str, float]]:
    """Obtiene temperatura observada real desde NWS API para settlement.

    Args:
        city_key: Clave de ciudad en CITY_CONFIG.
        target_date: Fecha objetivo. Default: hoy.

    Returns:
        Dict con 'high' y 'low' en Fahrenheit, o None si no disponible.
    """
    if city_key not in CITY_CONFIG:
        return None

    city = CITY_CONFIG[city_key]
    if target_date is None:
        target_date = date.today()

    try:
        station = city["nws_station"]
        url = f"https://api.weather.gov/stations/{station}/observations"
        headers = {"User-Agent": "(nachomarket-weather-bot, contact@example.com)"}

        start = datetime.combine(target_date, datetime.min.time()).isoformat() + "Z"
        end = datetime.combine(
            target_date + timedelta(days=1), datetime.min.time()
        ).isoformat() + "Z"

        response = requests.get(
            url, params={"start": start, "end": end}, headers=headers, timeout=15.0
        )
        response.raise_for_status()
        data = response.json()

        features = data.get("features", [])
        if not features:
            return None

        temps: list[float] = []
        for obs in features:
            props = obs.get("properties", {})
            temp_c = props.get("temperature", {}).get("value")
            if temp_c is not None:
                temps.append(_celsius_to_fahrenheit(float(temp_c)))

        if not temps:
            return None

        return {"high": max(temps), "low": min(temps)}

    except Exception as e:
        logger.warning(f"Failed to fetch NWS observations for {city_key}: {e}")
        return None
