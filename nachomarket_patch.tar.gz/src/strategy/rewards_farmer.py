"""LP Rewards Farming Optimizer v3.

Estrategia two-sided optimizada para maximizar Q_min en la formula de
liquidity rewards de Polymarket (abril 2026):

  S(v,s) = ((v-s)/v)^2 * b          Scoring cuadratico por orden
  Q_one  = S(yes) * BidSize_yes + S(no) * AskSize_no
  Q_two  = S(yes) * AskSize_yes + S(no) * BidSize_no
  Q_min  = max(min(Q_one, Q_two), max(Q_one/3, Q_two/3))   (mid en [0.10,0.90])

Clave: YES + NO = 1.0. Para maximizar Q_min con BIDs en ambos lados,
ambos lados deben aportar la MISMA cantidad de SHARES (no USD).
Esto obliga a invertir mas USD en el token caro y menos en el barato.

Ejemplo con $50 total, YES=0.15, NO=0.85:
  shares = 50 (balanceado)
  USD_YES = 50 * 0.15 = $7.50
  USD_NO  = 50 * 0.85 = $42.50
  Q_one = Q_two = S * 50  →  Q_min = S * 50 (maximo posible)

Si invirtieramos $25 en cada lado:
  shares_YES = 166.7, shares_NO = 29.4
  Q_one = S * 166.7, Q_two = S * 29.4
  Q_min = max(29.4, 55.6) = 55.6  (mucho menor que 50 * S)

Politica de ordenes: nunca cancelar ciegamente. Se obtienen las ordenes
abiertas, se comparan precios/size, y solo se recoloca si cambio > 2 ticks
o la orden dejo de scorear (S < 0.10). Esto preserva la cola FIFO y
maximiza el tiempo acumulado scoreando.

Batch orders: hasta 15 ordenes por request via post_orders() del SDK.

Referencia: https://docs.polymarket.com/market-makers/liquidity-rewards
"""

import logging
import math
from datetime import datetime, timezone
from typing import Any

from src.strategy.base import BaseStrategy, Signal, Trade

logger = logging.getLogger("nachomarket.strategy.rewards_farmer")

# --- Constantes oficiales de Polymarket ---
SINGLE_SIDED_DIVISOR = 3.0  # c en Q_min
MIN_SHARES_FALLBACK = 20    # minimo practico si la API no reporta rewards_min_size
TICK_MOVE_THRESHOLD = 2     # recolocar solo si el precio cambio >= N ticks
SIZE_CHANGE_PCT = 0.10      # recolocar si el size cambio >= 10%
MIN_SCORE_TO_KEEP = 0.10    # S minimo para mantener una orden abierta


class RewardsFarmerStrategy(BaseStrategy):
    """Farming de rewards two-sided con Q_min real y gestion inteligente de ordenes."""

    def __init__(self, client: Any, config: dict[str, Any], **kwargs: Any) -> None:
        super().__init__("rewards_farmer", client, config, **kwargs)
        rf_cfg = config.get("rewards_farmer", {})
        markets_cfg = config.get("markets", config)

        self._max_capital_per_market = float(rf_cfg.get("max_capital_per_market", 50.0))
        self._min_rewards_pool_usd = float(rf_cfg.get("min_rewards_pool_usd", 0.0))
        self._max_markets = int(rf_cfg.get("max_markets_simultaneous", 5))
        self._spread_pct = float(rf_cfg.get("spread_pct_of_max", 0.50))
        self._two_sided = bool(rf_cfg.get("two_sided", True))
        self._merge_threshold = float(rf_cfg.get("inventory_merge_threshold", 5.0))
        self._min_share_pct = float(rf_cfg.get("competition_share_min", 0.05))
        self._max_mid_deviation = float(rf_cfg.get("max_mid_deviation", 0.35))

        # Time windows
        tw = markets_cfg.get("time_windows", {})
        self._low_activity_hours: set[int] = set(tw.get("low_activity_hours", []))
        self._low_activity_factor: float = tw.get("low_activity_size_factor", 0.5)
        self._prime_hours: set[int] = set(tw.get("prime_placement_window_utc", [0, 1, 2, 3]))
        self._prime_boost: float = tw.get("prime_size_boost", 1.3)

        # Estado
        self._active_farms: dict[str, dict[str, Any]] = {}
        self._fill_inventory: dict[str, dict[str, float]] = {}
        self._reward_pct: dict[str, float] = {}
        self._pending_orders: dict[str, Signal] = {}

        self._logger.info(
            "RF v3 inicializado: two_sided=%s spread_pct=%.2f max_capital=%.0f max_mkts=%d",
            self._two_sided, self._spread_pct, self._max_capital_per_market, self._max_markets,
        )

    # ------------------------------------------------------------------
    # BaseStrategy interface
    # ------------------------------------------------------------------

    def should_act(self, market_data: dict[str, Any]) -> bool:
        rewards_rate = float(market_data.get("rewards_rate", 0.0))
        condition_id = market_data.get("condition_id", "")
        mid_price = float(market_data.get("mid_price", 0.0))

        if self._min_rewards_pool_usd > 0 and rewards_rate < self._min_rewards_pool_usd:
            self._logger.info(
                "RF skip %s...: rewards_pool=%.2f USD/dia (min %.2f)",
                condition_id[:12], rewards_rate, self._min_rewards_pool_usd,
            )
            return False

        if mid_price <= 0.0:
            self._logger.info("RF skip %s...: mid_price=0 (WS data pending)", condition_id[:12])
            return False
        if abs(mid_price - 0.50) > self._max_mid_deviation:
            self._logger.info(
                "RF skip %s...: mid=%.4f fuera de [%.2f, %.2f]",
                condition_id[:12], mid_price,
                0.50 - self._max_mid_deviation, 0.50 + self._max_mid_deviation,
            )
            return False

        phase = self._detect_market_phase(market_data)
        if phase == "live":
            self._logger.info("RF skip %s...: phase=live (riesgo directional)", condition_id[:12])
            return False

        tokens = market_data.get("tokens", [])
        if not tokens or len(tokens) < 2:
            return False
        token_data = market_data.get("token_data", {})
        rewards_min_size = float(market_data.get("rewards_min_size", 0.0))
        min_shares = max(MIN_SHARES_FALLBACK, rewards_min_size)

        can_any = False
        for token in tokens:
            tid = token.get("token_id", "")
            t_mid = float(token_data.get(tid, {}).get("mid_price", mid_price))
            if t_mid <= 0:
                continue
            side_capital = self._max_capital_per_market / (2.0 if self._two_sided else 1.0)
            required_usd = min_shares * t_mid
            if required_usd <= side_capital:
                can_any = True
                break
            if not self._two_sided and required_usd <= self._max_capital_per_market:
                can_any = True
                break

        if not can_any:
            self._logger.info(
                "RF skip %s...: ni un lado alcanza min_shares=%.0f con capital disponible",
                condition_id[:12], min_shares,
            )
            return False

        if len(self._active_farms) >= self._max_markets and condition_id not in self._active_farms:
            self._logger.info("RF skip %s...: max_markets=%d reached", condition_id[:12], self._max_markets)
            return False

        self._logger.info(
            "RF ACT: %s... mid=%.4f pool=$%.2f/dia phase=%s",
            condition_id[:12], mid_price, rewards_rate, phase,
        )
        return True

    def evaluate(self, market_data: dict[str, Any]) -> list[Signal]:
        condition_id = market_data.get("condition_id", "")
        rewards_rate = float(market_data.get("rewards_rate", 0.0))
        rewards_min_size = float(market_data.get("rewards_min_size", 0.0))
        rewards_max_spread = float(market_data.get("rewards_max_spread", 0.0))
        if not condition_id:
            return []

        tokens = market_data.get("tokens", [])
        token_data = market_data.get("token_data", {})
        if not tokens or len(tokens) < 2:
            return []

        max_spread_usd = rewards_max_spread / 100.0 if rewards_max_spread > 0 else 0.04
        min_shares = max(MIN_SHARES_FALLBACK, rewards_min_size)
        tick_size = float(market_data.get("tick_size", 0.01))

        # Mids
        yes_td = token_data.get(tokens[0].get("token_id", ""), {})
        no_td = token_data.get(tokens[1].get("token_id", ""), {})
        yes_mid = float(yes_td.get("mid_price", 0.0))
        no_mid = float(no_td.get("mid_price", 0.0))
        if yes_mid <= 0 or no_mid <= 0:
            return []

        pair_mid = yes_mid + no_mid
        if pair_mid <= 0:
            return []

        # Cash disponible (inyectado por main.py)
        available_cash = float(market_data.get("available_cash", self._max_capital_per_market))
        max_total_usd = min(self._max_capital_per_market, available_cash * 0.98)

        # Shares por lado: balanceado para maximizar Q_min
        # Con BIDs en ambos lados, Q_one = S_yes * shares_yes, Q_two = S_no * shares_no
        # Si S_yes ≈ S_no (misma distancia en centavos), Q_min se maximiza cuando shares_yes ≈ shares_no
        # Capital = shares * yes_mid + shares * no_mid = shares * pair_mid
        # => shares = max_total_usd / pair_mid
        base_shares = max(min_shares, max_total_usd / pair_mid)

        # Boost de ventana horaria
        now_utc = datetime.now(timezone.utc).hour
        boost = 1.0
        if now_utc in self._prime_hours:
            boost = self._prime_boost
        elif now_utc in self._low_activity_hours:
            boost = self._low_activity_factor

        # Aplicar boost manteniendo el capital total
        if boost != 1.0:
            raw_total = base_shares * pair_mid * boost
            if raw_total > max_total_usd:
                base_shares = max_total_usd / (pair_mid * boost)
            # else: boost aumenta shares sin exceder capital

        # Target score para distancia (0.50 = centro del max_spread)
        target_score = 0.50
        reward_share = self._reward_pct.get(condition_id, 0.0)
        if reward_share > 20.0:
            target_score = 0.60
        elif reward_share < 5.0:
            target_score = 0.40
        if now_utc in self._prime_hours:
            target_score = min(target_score * 1.10, 0.80)

        signals: list[Signal] = []
        token_infos = [
            {"token": tokens[0], "mid": yes_mid, "td": yes_td, "outcome": "yes"},
            {"token": tokens[1], "mid": no_mid, "td": no_td, "outcome": "no"},
        ]

        for tinfo in token_infos:
            token = tinfo["token"]
            t_mid = tinfo["mid"]
            td = tinfo["td"]
            tid = token.get("token_id", "")
            if not tid:
                continue

            asks_book = td.get("orderbook", {}).get("asks", [])
            best_ask = float(asks_book[0].get("price", asks_book[0].get("p", 1.0))) if asks_book else td.get("best_ask", 1.0)

            # Distancia normalizada por precio del token
            # S(v,s) = ((v-s)/v)^2. v = max_spread_usd, s = distance_usd
            # Resolviendo para s con target_score: s = v * (1 - sqrt(target_score))
            distance_usd = max_spread_usd * (1.0 - math.sqrt(target_score))
            # Normalizar: un token a 0.80 puede aguantar mas distancia que uno a 0.20
            # Pero v es fijo por mercado, asi que la distancia absoluta en USD es la misma.
            # Sin embargo, para no quedar fuera del book en tokens caros, clamp por tick_size.
            distance_usd = max(distance_usd, tick_size)

            bid_price = self._calc_bid_price(t_mid, distance_usd, best_ask, max_spread_usd, tick_size)
            if bid_price <= 0 or bid_price >= t_mid:
                continue

            # Size en USD: shares balanceadas * mid del token
            # (base_shares ya absorbe el boost si hubiera)
            size_usd = base_shares * t_mid
            side_capital = max_total_usd * t_mid / pair_mid
            size_usd = round(min(size_usd, side_capital), 2)
            if size_usd < min_shares * t_mid * 0.9:
                continue

            # Validar score
            s_usd = t_mid - bid_price
            v_usd = max_spread_usd
            score = ((v_usd - s_usd) / v_usd) ** 2 if v_usd > 0 else 0.0
            if score < MIN_SCORE_TO_KEEP:
                bid_price = self._calc_bid_price(t_mid, tick_size, best_ask, max_spread_usd, tick_size)
                if bid_price <= 0:
                    continue
                score = ((v_usd - (t_mid - bid_price)) / v_usd) ** 2 if v_usd > 0 else 0.0

            signals.append(Signal(
                strategy_name=self.name,
                market_id=condition_id,
                token_id=tid,
                side="BUY",
                price=bid_price,
                size=size_usd,
                confidence=0.7,
                metadata={
                    "reason": f"rf_v3: rate={rewards_rate:.2f}/day target_score={target_score:.2f}",
                    "phase": self._detect_market_phase(market_data),
                    "score": round(score, 4),
                    "shares": round(base_shares * boost, 2),
                },
            ))

        if not self._two_sided and signals:
            signals = [signals[0]]

        return signals

    def execute(self, signals: list[Signal]) -> list[Trade]:
        trades: list[Trade] = []
        if not signals:
            return trades

        # 1. Obtener ordenes abiertas actuales del exchange
        open_orders: list[dict[str, Any]] = []
        try:
            open_orders = self._client.get_positions() or []
        except Exception:
            self._logger.exception("RF: error obteniendo ordenes abiertas")

        # Indexar ordenes abiertas por token_id (solo nuestras BIDs)
        open_by_token: dict[str, list[dict[str, Any]]] = {}
        for oo in open_orders:
            tid = oo.get("asset_id") or oo.get("token_id") or ""
            side = str(oo.get("side", "")).upper()
            if tid and side == "BUY":
                open_by_token.setdefault(tid, []).append(oo)

        # 2. Decidir que cancelar y que colocar
        to_cancel: list[str] = []
        to_place: list[Signal] = []
        signal_tokens = {s.token_id: s for s in signals}

        for sig in signals:
            existing = open_by_token.get(sig.token_id, [])
            if not existing:
                to_place.append(sig)
                continue

            oo = existing[0]
            oo_price = float(oo.get("price", 0.0))
            oo_size = float(oo.get("original_size", oo.get("size", 0.0)))
            tick_size = 0.01  # se podria obtener del market_data

            price_diff_ticks = abs(round((sig.price - oo_price) / tick_size))
            size_diff_pct = abs(sig.size - oo_size) / max(oo_size, 1e-9)

            if price_diff_ticks >= TICK_MOVE_THRESHOLD or size_diff_pct >= SIZE_CHANGE_PCT:
                oid = str(oo.get("id", oo.get("order_id", "")))
                if oid:
                    to_cancel.append(oid)
                to_place.append(sig)
            else:
                self._logger.debug(
                    "RF: manteniendo orden %s en %s @ %.4f (diff %d ticks, size %.1f%%)",
                    str(oo.get("id", ""))[:12], sig.token_id[:8], oo_price,
                    price_diff_ticks, size_diff_pct * 100,
                )

        # Cancelar ordenes de tokens que ya no estan en signals
        for tid, oos in open_by_token.items():
            if tid not in signal_tokens:
                for oo in oos:
                    oid = str(oo.get("id", oo.get("order_id", "")))
                    if oid:
                        to_cancel.append(oid)

        # 3. Ejecutar cancelaciones
        for oid in to_cancel:
            try:
                self._client.cancel_order(oid)
                self._pending_orders.pop(oid, None)
            except Exception:
                self._logger.debug("RF: error cancelando orden %s...", oid[:12])

        # 4. Ejecutar colocaciones (batch si es posible)
        if to_place:
            try:
                if hasattr(self._client, "post_batch_orders"):
                    batch_results = self._client.post_batch_orders(to_place)
                    for sig, res in zip(to_place, batch_results):
                        trade = self._build_trade(sig, res)
                        trades.append(trade)
                        if trade.order_id and trade.status not in ("error", "rejected"):
                            self._pending_orders[trade.order_id] = sig
                else:
                    for sig in to_place:
                        res = self._client.place_limit_order(
                            token_id=sig.token_id,
                            side=sig.side,
                            price=sig.price,
                            size=sig.size,
                            post_only=True,
                        )
                        trade = self._build_trade(sig, res)
                        trades.append(trade)
                        if trade.order_id and trade.status not in ("error", "rejected"):
                            self._pending_orders[trade.order_id] = sig
            except Exception:
                self._logger.exception("RF: error colocando ordenes")
                for sig in to_place:
                    trades.append(Trade(
                        timestamp=datetime.now(timezone.utc).isoformat(),
                        strategy_name=self.name,
                        market_id=sig.market_id,
                        token_id=sig.token_id,
                        side=sig.side,
                        price=sig.price,
                        size=sig.size,
                        status="error",
                        order_id="",
                    ))

        # 5. Actualizar _active_farms
        for sig in signals:
            if sig.market_id not in self._active_farms:
                self._active_farms[sig.market_id] = {}
            self._active_farms[sig.market_id][sig.token_id] = {
                "side": sig.side,
                "size": sig.size,
                "price": sig.price,
            }

        return trades

    # ------------------------------------------------------------------
    # Fills e inventario
    # ------------------------------------------------------------------

    def record_fill(self, token_id: str, side: str, size: float, market_id: str, tokens: list[dict[str, Any]]) -> None:
        """Registra un fill en el inventario local del RF.

        Usa token_id para determinar si es YES o NO, no el side.
        """
        if market_id not in self._fill_inventory:
            self._fill_inventory[market_id] = {"yes": 0.0, "no": 0.0}
        inv = self._fill_inventory[market_id]

        yes_id = tokens[0].get("token_id", "") if len(tokens) > 0 else ""
        key = "yes" if token_id == yes_id else "no"

        if side == "BUY":
            inv[key] = inv.get(key, 0.0) + size
        elif side == "SELL":
            inv[key] = max(0.0, inv.get(key, 0.0) - size)

    def get_fill_inventory(self, market_id: str) -> dict[str, float]:
        return self._fill_inventory.get(market_id, {"yes": 0.0, "no": 0.0})

    def should_merge(self, market_id: str) -> bool:
        inv = self._fill_inventory.get(market_id, {})
        return min(inv.get("yes", 0.0), inv.get("no", 0.0)) >= self._merge_threshold

    def mark_merged(self, market_id: str, merged_amount: float) -> None:
        if market_id in self._fill_inventory:
            inv = self._fill_inventory[market_id]
            inv["yes"] = max(0.0, inv.get("yes", 0.0) - merged_amount)
            inv["no"] = max(0.0, inv.get("no", 0.0) - merged_amount)

    def update_reward_pct(self, percentages: dict[str, float]) -> None:
        self._reward_pct.update(percentages)

    def get_low_share_markets(self) -> list[str]:
        return [
            cid for cid, pct in self._reward_pct.items()
            if pct < self._min_share_pct and cid in self._active_farms
        ]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_trade(self, sig: Signal, result: dict[str, Any]) -> Trade:
        """Construye un Trade desde un Signal y el dict resultado del SDK."""
        status = result.get("status", "unknown")
        order_id = result.get("order_id", result.get("orderID", ""))
        return Trade(
            timestamp=datetime.now(timezone.utc).isoformat(),
            strategy_name=self.name,
            market_id=sig.market_id,
            token_id=sig.token_id,
            side=sig.side,
            price=sig.price,
            size=sig.size,
            status=status,
            order_id=order_id,
        )

    @staticmethod
    def _calc_bid_price(
        mid: float,
        distance: float,
        best_ask: float,
        max_spread_usd: float,
        tick_size: float,
    ) -> float:
        """Calcula precio de BID respetando max_spread y post-only."""
        bid = round(mid - distance, 4)
        if best_ask > 0 and bid >= best_ask:
            bid = round(best_ask - tick_size, 4)
        bid = max(tick_size, bid)
        if bid < mid - max_spread_usd:
            bid = round(mid - max_spread_usd, 4)
        return bid if 0 < bid < mid else 0.0

    @staticmethod
    def _detect_market_phase(market_data: dict[str, Any]) -> str:
        category = str(market_data.get("category", "")).lower()
        if category in ("sports", "esports"):
            end_str = str(market_data.get("end_date", ""))
            if end_str:
                try:
                    end_date = datetime.fromisoformat(end_str.replace("Z", "+00:00"))
                    hours_remaining = (end_date - datetime.now(timezone.utc)).total_seconds() / 3600.0
                except (ValueError, TypeError):
                    hours_remaining = 9999
                if hours_remaining > 3:
                    return "pre_game"
                elif hours_remaining > 0:
                    return "live"
                else:
                    return "post_game"
        return "standard"

    def should_exit_live(self, market_data: dict[str, Any]) -> bool:
        phase = self._detect_market_phase(market_data)
        condition_id = market_data.get("condition_id", "")
        inv = self.get_fill_inventory(condition_id)
        has_inventory = inv.get("yes", 0.0) > 0 or inv.get("no", 0.0) > 0
        return phase == "live" or (phase == "post_game" and not has_inventory)
