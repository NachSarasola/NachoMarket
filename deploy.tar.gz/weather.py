"""Weather Temperature Trading Strategy.

Usa Open-Meteo Ensemble API (GFS, 31 miembros) para estimar probabilidades
de mercados de temperatura en Polymarket y tradear contra el mercado cuando
el edge del ensemble supera el umbral configurado.

Inspirada fielmente en polymarket-kalshi-weather-bot de suislánchez.

Flujo:
  1. Descubrir mercados de temperatura via Gamma API (tag=Weather)
  2. Para cada mercado: fetch ensemble forecast → calcular probabilidad
  3. Edge = model_prob - market_prob → filtrar por min_edge_threshold
  4. Kelly fraccional para sizing
  5. Ejecutar ordenes reales en CLOB (somos takers)
  6. Verificar settlements (mercados resueltos → cerrar posiciones)
"""

import logging
import math
import re
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Optional

import requests

from src.data.weather import (
    CITY_ALIASES,
    CITY_CONFIG,
    MONTH_MAP,
    EnsembleForecast,
    fetch_ensemble_forecast,
)
from src.strategy.base import BaseStrategy, Signal, Trade

logger = logging.getLogger("nachomarket.strategy.weather")

GAMMA_API_URL = "https://gamma-api.polymarket.com/events"


@dataclass
class WeatherMarket:
    """Mercado de temperatura parseado de Polymarket."""

    slug: str
    market_id: str
    platform: str
    title: str
    city_key: str
    city_name: str
    target_date: date
    threshold_f: float
    metric: str
    direction: str
    yes_price: float
    no_price: float
    tokens: list[dict[str, Any]] = field(default_factory=list)
    volume: float = 0.0
    closed: bool = False


class WeatherStrategy(BaseStrategy):
    """Estrategia de trading en mercados de temperatura usando ensemble forecasting.

    No opera via el pipeline normal de active_markets del bot principal.
    En su lugar, tiene su propio metodo run_scan() llamado desde un schedule job
    dedicado cada N minutos (configurable).
    """

    def __init__(
        self,
        client: Any,
        config: dict[str, Any],
        position_sizer: Any = None,
        circuit_breaker: Any = None,
        inventory: Any = None,
        **kwargs: Any,
    ) -> None:
        super().__init__("weather", client, config, **kwargs)
        self._position_sizer = position_sizer
        self._circuit_breaker = circuit_breaker
        self._inventory = inventory

        wcfg = config.get("weather", {})
        self._enabled = bool(wcfg.get("enabled", False))
        self._scan_interval_min = int(wcfg.get("scan_interval_minutes", 5))
        self._min_edge_threshold = float(wcfg.get("min_edge_threshold", 0.08))
        self._max_entry_price = float(wcfg.get("max_entry_price", 0.70))
        self._max_trade_size = float(wcfg.get("max_trade_size_usdc", 25.0))
        self._max_total_allocation = float(wcfg.get("max_total_allocation", 50.0))
        self._max_trades_per_scan = int(wcfg.get("max_trades_per_scan", 3))
        self._kelly_fraction = float(wcfg.get("kelly_fraction", 0.15))
        self._city_keys: list[str] = [
            c.strip()
            for c in wcfg.get("cities", "nyc,chicago,miami,los_angeles,denver").split(",")
            if c.strip()
        ]

        # Tracking de posiciones abiertas
        self._open_positions: dict[str, WeatherMarket] = {}
        # Cache de mercados descubiertos (5min TTL)
        self._markets_cache: list[WeatherMarket] = []
        self._markets_cache_ts: float = 0.0
        self._markets_cache_ttl: float = 300.0
        # Pending signals (para no duplicar ordenes en el mismo mercado)
        self._pending_market_ids: set[str] = set()
        # Estadisticas
        self._signals_generated: int = 0
        self._trades_executed: int = 0

        self._logger.info(
            "WeatherStrategy inicializada: cities=%s edge_min=%.0f%% max_trade=%.0f "
            "max_alloc=%.0f kelly=%.0f%% scan=%dmin",
            self._city_keys,
            self._min_edge_threshold * 100,
            self._max_trade_size,
            self._max_total_allocation,
            self._kelly_fraction * 100,
            self._scan_interval_min,
        )

    # ------------------------------------------------------------------
    # BaseStrategy interface
    # ------------------------------------------------------------------

    def should_act(self, market_data: dict[str, Any]) -> bool:
        """Weather no opera via pipeline normal de active_markets."""
        return False

    def evaluate(self, market_data: dict[str, Any]) -> list[Signal]:
        """No se usa via main loop. Las senales se generan en run_scan()."""
        return []

    def execute(self, signals: list[Signal], market_map: dict[str, "WeatherMarket"] | None = None) -> list[Trade]:
        """Ejecuta senales de weather como ordenes reales en el CLOB."""
        trades: list[Trade] = []
        for signal in signals:
            try:
                token_id = signal.token_id
                side = signal.side
                price = signal.price
                size = signal.size

                market_price = float(signal.metadata.get("market_price", price))
                shares = self._calc_shares(size, market_price)

                if shares <= 0:
                    self._logger.warning(
                        "Weather signal con size 0: %s %s @ %.4f",
                        side, token_id[:12], price,
                    )
                    continue

                order = self._client.place_limit_order(
                    token_id=token_id,
                    price=price,
                    size=shares,
                    side=side,
                    post_only=False,
                )

                order_id = order.get("id") or order.get("order_id", "")
                status = order.get("status", "submitted")

                trade = self._make_trade(signal, order_id or f"weather_{int(time.time())}", status)
                self.log_trade(trade)
                trades.append(trade)

                market_id = signal.market_id
                self._pending_market_ids.add(market_id)
                self._trades_executed += 1

                if market_map and market_id in market_map:
                    self._open_positions[market_id] = market_map[market_id]

                self._logger.info(
                    "Weather trade: %s %s %.2f shares @ %.4f (%s) | order=%s",
                    side, token_id[:12], shares, price, signal.metadata.get("reasoning", ""), order_id,
                )

            except Exception as e:
                self._logger.exception("Error ejecutando weather signal: %s", e)
                self._make_trade_and_log_error(signal, str(e), trades)

        return trades

    # ------------------------------------------------------------------
    # Main scan method — llamado desde schedule job en main.py
    # ------------------------------------------------------------------

    def run_scan(self, balance: float, cached_positions: dict[str, Any]) -> list[Trade]:
        """Ciclo completo de weather trading.

        Args:
            balance: Balance USDC cacheado.
            cached_positions: Posiciones del InventoryManager.

        Returns:
            Lista de Trade ejecutados.
        """
        if not self._active:
            return []

        if self._circuit_breaker is not None and self._circuit_breaker.is_triggered():
            self._logger.debug("Weather scan: circuit breaker activo, saltando")
            return []

        all_trades: list[Trade] = []

        # 1. Settlement check
        settlement_trades = self._check_settlements()
        all_trades.extend(settlement_trades)

        # 2. Limpiar pending_market_ids de mercados ya resueltos o cerrados
        resolved_ids = {t.market_id for t in settlement_trades}
        self._pending_market_ids -= resolved_ids

        # 3. Descubrir mercados
        markets = self._discover_weather_markets()

        if not markets:
            self._logger.debug("Weather scan: sin mercados de temperatura encontrados")
            return all_trades

        # 4. Calcular exposure actual en weather
        weather_exposure = self._calc_weather_exposure(cached_positions)

        # 5. Generar senales (y mapear a WeatherMarket para settlement tracking)
        signals: list[Signal] = []
        signal_market_map: dict[str, WeatherMarket] = {}
        for market in markets:
            signal = self._generate_signal(market, balance)
            if signal is not None:
                signals.append(signal)
                signal_market_map[signal.market_id] = market

        self._signals_generated += len(signals)
        self._logger.info(
            "Weather scan: %d mercados → %d senales", len(markets), len(signals)
        )

        # 6. Filtrar por edge minimo y entry price
        actionable = [
            s for s in signals
            if abs(float(s.metadata.get("edge", 0.0))) >= self._min_edge_threshold
        ]

        # 7. Ordenar por |edge| descendente
        actionable.sort(key=lambda s: abs(float(s.metadata.get("edge", 0.0))), reverse=True)

        # 8. Aplicar limites
        trades_to_execute: list[Signal] = []
        running_exposure = weather_exposure

        for signal in actionable:
            if len(trades_to_execute) >= self._max_trades_per_scan:
                break

            market_id = signal.market_id
            if market_id in self._pending_market_ids:
                continue

            signal_size = signal.size
            if running_exposure + signal_size > self._max_total_allocation:
                self._logger.info(
                    "Weather alloc cap: exposure %.0f + trade %.0f > max %.0f",
                    running_exposure, signal_size, self._max_total_allocation,
                )
                continue

            if signal_size > self._max_trade_size:
                self._logger.info(
                    "Weather size cap: signal %.0f > max_trade %.0f",
                    signal_size, self._max_trade_size,
                )
                signal = self._make_signal(
                    market_id=signal.market_id,
                    token_id=signal.token_id,
                    side=signal.side,
                    price=signal.price,
                    size=self._max_trade_size,
                    confidence=signal.confidence,
                    metadata=signal.metadata,
                )

            # Verificar balance floor segun tip 16
            loss_reserve = float(self._config.get("loss_reserve_usdc", 20.0))
            if balance - signal.size < loss_reserve:
                self._logger.info(
                    "Weather: trade %.0f dejaria balance %.0f < reserve %.0f",
                    signal.size, balance - signal.size, loss_reserve,
                )
                continue

            trades_to_execute.append(signal)
            running_exposure += signal.size

        # 9. Ejecutar
        if trades_to_execute:
            self._logger.info(
                "Weather: ejecutando %d trades (edge: %s)",
                len(trades_to_execute),
                ", ".join(
                    f"{float(s.metadata.get('edge',0)):+.0%}"
                    for s in trades_to_execute
                ),
            )
            executed = self.execute(trades_to_execute, market_map=signal_market_map)
            all_trades.extend(executed)

        return all_trades

    # ------------------------------------------------------------------
    # Market discovery
    # ------------------------------------------------------------------

    def _discover_weather_markets(self) -> list[WeatherMarket]:
        """Descubre mercados de temperatura en Polymarket via Gamma API."""
        now = time.time()
        if self._markets_cache and (now - self._markets_cache_ts) < self._markets_cache_ttl:
            return self._markets_cache

        markets: list[WeatherMarket] = []
        seen_ids: set[str] = set()

        try:
            # Buscar por tag Weather
            for tag in ["Weather", "Weather+Temperature"]:
                params: dict[str, Any] = {
                    "closed": "false",
                    "limit": 100,
                    "tag": tag,
                }
                try:
                    response = requests.get(
                        GAMMA_API_URL, params=params, timeout=15.0
                    )
                    response.raise_for_status()
                    events = response.json()

                    for event in events:
                        if not isinstance(event, dict):
                            continue
                        event_slug = event.get("slug", "")
                        for mkt_data in event.get("markets", []):
                            wm = self._parse_polymarket_weather(
                                mkt_data, event_slug
                            )
                            if wm and wm.market_id not in seen_ids:
                                markets.append(wm)
                                seen_ids.add(wm.market_id)

                except Exception as e:
                    self._logger.debug("Weather tag search '%s': %s", tag, e)

            # Buscar por slug
            for slug_term in ["weather", "temperature", "temp-"]:
                try:
                    response = requests.get(
                        GAMMA_API_URL,
                        params={
                            "closed": "false",
                            "limit": 100,
                            "slug_contains": slug_term,
                        },
                        timeout=15.0,
                    )
                    response.raise_for_status()
                    events = response.json()

                    for event in events:
                        if not isinstance(event, dict):
                            continue
                        event_slug = event.get("slug", "")
                        for mkt_data in event.get("markets", []):
                            wm = self._parse_polymarket_weather(
                                mkt_data, event_slug
                            )
                            if wm and wm.market_id not in seen_ids:
                                markets.append(wm)
                                seen_ids.add(wm.market_id)

                except Exception as e:
                    self._logger.debug("Weather slug search '%s': %s", slug_term, e)

        except Exception as e:
            self._logger.warning("Weather market discovery failed: %s", e)

        self._markets_cache = markets
        self._markets_cache_ts = now
        self._logger.info(
            "Weather discovery: %d mercados de temperatura encontrados", len(markets)
        )
        return markets

    def _parse_polymarket_weather(
        self, market_data: dict[str, Any], event_slug: str
    ) -> Optional[WeatherMarket]:
        """Parsea un mercado de Polymarket y lo convierte en WeatherMarket."""
        question = (
            market_data.get("question", "")
            or market_data.get("groupItemTitle", "")
        )
        if not question:
            return None

        parsed = self._parse_weather_market_title(question)
        if not parsed:
            return None

        if parsed["city_key"] not in self._city_keys:
            return None

        if parsed["target_date"] < date.today():
            return None

        outcome_prices = market_data.get("outcomePrices", [])
        if isinstance(outcome_prices, str):
            import json
            try:
                outcome_prices = json.loads(outcome_prices)
            except Exception:
                outcome_prices = []

        if not outcome_prices or len(outcome_prices) < 2:
            return None

        try:
            yes_price = float(outcome_prices[0])
            no_price = float(outcome_prices[1])
        except (ValueError, IndexError):
            return None

        if market_data.get("closed", False):
            return None
        if yes_price > 0.98 or yes_price < 0.02:
            return None

        volume = float(market_data.get("volume", 0) or 0)

        tokens: list[dict[str, Any]] = []
        clob_ids = market_data.get("clobTokenIds", [])
        if isinstance(clob_ids, str):
            import json
            try:
                clob_ids = json.loads(clob_ids)
            except Exception:
                clob_ids = []

        for i, tid in enumerate(clob_ids):
            token_outcome = "Yes" if i == 0 else "No"
            tokens.append({"token_id": str(tid), "outcome": token_outcome})

        return WeatherMarket(
            slug=event_slug,
            market_id=str(market_data.get("id", "")),
            platform="polymarket",
            title=question,
            city_key=parsed["city_key"],
            city_name=parsed["city_name"],
            target_date=parsed["target_date"],
            threshold_f=parsed["threshold_f"],
            metric=parsed["metric"],
            direction=parsed["direction"],
            yes_price=yes_price,
            no_price=no_price,
            tokens=tokens,
            volume=volume,
        )

    # ------------------------------------------------------------------
    # Title parsing (regex)
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_weather_market_title(title: str) -> Optional[dict[str, Any]]:
        """Parsea titulo de mercado de temperatura.

        Ejemplos:
          "Will the high temperature in New York exceed 75°F on March 5?"
          "NYC high temperature above 80°F on March 10, 2026"
          "Chicago daily high over 60°F on March 3"
          "Will Miami's low be above 65°F on March 7?"
          "Temperature in Denver above 70°F on March 5, 2026"
        """
        title_lower = title.lower()

        if not any(
            kw in title_lower
            for kw in ["temperature", "temp", "°f", "degrees", "high", "low"]
        ):
            return None

        city_key: Optional[str] = None
        city_name: Optional[str] = None
        for alias, key in sorted(CITY_ALIASES.items(), key=lambda x: -len(x[0])):
            if alias in title_lower:
                city_key = key
                city_name = CITY_CONFIG[key]["name"]
                break

        if not city_key:
            return None

        temp_match = re.search(r"(\d+)\s*°?\s*f", title_lower)
        if not temp_match:
            temp_match = re.search(r"(\d+)\s*degrees", title_lower)
        if not temp_match:
            return None
        threshold_f = float(temp_match.group(1))

        metric = "high"
        if "low" in title_lower:
            metric = "low"

        direction = "above"
        if any(
            kw in title_lower
            for kw in ["below", "under", "less than", "drop below"]
        ):
            direction = "below"

        target_date = WeatherStrategy._extract_date(title_lower)
        if not target_date:
            return None

        return {
            "city_key": city_key,
            "city_name": city_name,
            "threshold_f": threshold_f,
            "metric": metric,
            "direction": direction,
            "target_date": target_date,
        }

    @staticmethod
    def _extract_date(text: str) -> Optional[date]:
        """Extrae fecha de texto de titulo de mercado."""
        today = date.today()
        month_names = "|".join(MONTH_MAP.keys())

        for match in re.finditer(
            rf"({month_names})\s+(\d{{1,2}})(?:\s*,?\s*(\d{{4}}))?", text
        ):
            month_str = match.group(1)
            day = int(match.group(2))
            year = int(match.group(3)) if match.group(3) else today.year

            month = MONTH_MAP.get(month_str)
            if month and 1 <= day <= 31:
                try:
                    return date(year, month, day)
                except ValueError:
                    continue

        match = re.search(r"(\d{1,2})/(\d{1,2})(?:/(\d{4}))?", text)
        if match:
            month = int(match.group(1))
            day = int(match.group(2))
            year = int(match.group(3)) if match.group(3) else today.year
            try:
                return date(year, month, day)
            except ValueError:
                pass

        return None

    # ------------------------------------------------------------------
    # Signal generation
    # ------------------------------------------------------------------

    def _generate_signal(
        self, market: WeatherMarket, balance: float
    ) -> Optional[Signal]:
        """Genera una senal de trading para un mercado de temperatura.

        Usa ensemble forecast para estimar probabilidad y calcular edge.
        """
        forecast = fetch_ensemble_forecast(market.city_key, market.target_date)
        if forecast is None or not forecast.member_highs:
            return None

        if market.metric == "high":
            if market.direction == "above":
                model_yes_prob = forecast.probability_high_above(market.threshold_f)
            else:
                model_yes_prob = forecast.probability_high_below(market.threshold_f)
        else:
            if market.direction == "above":
                model_yes_prob = forecast.probability_low_above(market.threshold_f)
            else:
                model_yes_prob = forecast.probability_low_below(market.threshold_f)

        model_yes_prob = max(0.05, min(0.95, model_yes_prob))

        market_yes_prob = market.yes_price

        # Calcular edge
        up_edge = model_yes_prob - market_yes_prob
        down_edge = (1.0 - model_yes_prob) - (1.0 - market_yes_prob)

        if up_edge >= down_edge:
            edge = up_edge
            direction_raw = "up"
            side = "BUY"
            token_index = 0  # YES token
            entry_price = market.yes_price
        else:
            edge = down_edge
            direction_raw = "down"
            side = "BUY"
            token_index = 1  # NO token
            entry_price = market.no_price

        if entry_price > self._max_entry_price:
            edge = 0.0

        # Confidence: ensemble agreement respecto al threshold
        if market.metric == "high":
            members = forecast.member_highs
        else:
            members = forecast.member_lows

        above_count = sum(1 for m in members if m > market.threshold_f)
        agreement_frac = max(above_count, len(members) - above_count) / len(members)
        confidence = min(0.9, agreement_frac)

        # Kelly sizing
        win_prob = model_yes_prob if direction_raw == "up" else (1.0 - model_yes_prob)
        price_for_kelly = market_yes_prob if direction_raw == "up" else (1.0 - market_yes_prob)

        if price_for_kelly <= 0 or price_for_kelly >= 1:
            kelly = 0.0
        else:
            odds = (1.0 - price_for_kelly) / price_for_kelly
            lose_prob = 1.0 - win_prob
            kelly = (win_prob * odds - lose_prob) / odds if odds > 0 else 0.0

        kelly *= self._kelly_fraction
        kelly = min(kelly, 0.05)
        kelly = max(kelly, 0.0)

        size = kelly * balance
        size = min(size, self._max_trade_size)

        if size <= 0:
            return None

        # Obtener token_id
        token_id = ""
        if market.tokens and len(market.tokens) > token_index:
            token_id = str(market.tokens[token_index].get("token_id", ""))
        if not token_id:
            self._logger.debug("Weather market sin tokens: %s", market.market_id)
            return None

        # Determinar precio de la orden
        order_price = entry_price

        mean_val = forecast.mean_high if market.metric == "high" else forecast.mean_low
        std_val = forecast.std_high if market.metric == "high" else forecast.std_low

        reasoning = (
            f"{market.city_name} {market.metric} {market.direction} "
            f"{market.threshold_f:.0f}F on {market.target_date} | "
            f"Ensemble: {mean_val:.1f}F +/- {std_val:.1f}F "
            f"({forecast.num_members}m) | "
            f"Model YES: {model_yes_prob:.0%} vs Market: {market_yes_prob:.0%} | "
            f"Edge: {edge:+.1%} -> {side} @ {order_price:.4f} | "
            f"Agreement: {agreement_frac:.0%} | Kelly: {kelly:.3f}"
        )

        return self._make_signal(
            market_id=market.market_id,
            token_id=token_id,
            side=side,
            price=order_price,
            size=size,
            confidence=confidence,
            metadata={
                "model_probability": model_yes_prob,
                "market_probability": market_yes_prob,
                "edge": edge,
                "direction_raw": direction_raw,
                "entry_price": entry_price,
                "market_price": entry_price,
                "ensemble_mean": mean_val,
                "ensemble_std": std_val,
                "ensemble_members": forecast.num_members,
                "agreement": agreement_frac,
                "kelly_fraction": kelly,
                "city_key": market.city_key,
                "city_name": market.city_name,
                "threshold_f": market.threshold_f,
                "metric": market.metric,
                "direction": market.direction,
                "target_date": market.target_date.isoformat(),
                "reasoning": reasoning,
                "category": "weather",
            },
        )

    # ------------------------------------------------------------------
    # Settlement
    # ------------------------------------------------------------------

    def _check_settlements(self) -> list[Trade]:
        """Verifica si mercados abiertos se resolvieron y cierra posiciones."""
        trades: list[Trade] = []
        resolved: list[str] = []

        # Chequear tanto open_positions como pending_market_ids
        all_open_ids = set(self._open_positions.keys()) | self._pending_market_ids

        for market_id in list(all_open_ids):
            try:
                response = requests.get(
                    f"https://gamma-api.polymarket.com/markets/{market_id}",
                    timeout=10.0,
                )
                response.raise_for_status()
                data = response.json()

                if not data.get("closed", False):
                    continue

                outcome_prices = data.get("outcomePrices", [])
                if isinstance(outcome_prices, str):
                    import json
                    try:
                        outcome_prices = json.loads(outcome_prices)
                    except Exception:
                        outcome_prices = []

                if not outcome_prices:
                    resolved.append(market_id)
                    continue

                yes_price = float(outcome_prices[0])
                if yes_price > 0.99:
                    winner = "YES"
                elif yes_price < 0.01:
                    winner = "NO"
                else:
                    winner = "UNKNOWN"

                self._logger.info(
                    "Weather settlement: %s resolved -> %s",
                    market_id[:14], winner,
                )
                resolved.append(market_id)

            except Exception as e:
                self._logger.debug("Weather settlement check error %s: %s", market_id[:14], e)

        for market_id in resolved:
            self._open_positions.pop(market_id, None)
            self._pending_market_ids.discard(market_id)
            # Limpiar inventario si existe
            if self._inventory is not None:
                try:
                    self._inventory.clear_market(market_id)
                except Exception:
                    pass

        return trades

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _calc_shares(self, size_usdc: float, price: float) -> float:
        """Convierte size en USDC a shares."""
        if price <= 0 or price >= 1:
            return 0.0
        return math.floor(size_usdc / price)

    def _calc_weather_exposure(self, cached_positions: dict[str, Any]) -> float:
        """Calcula exposure actual en mercados de weather."""
        total = 0.0
        for market_id in self._pending_market_ids:
            positions = cached_positions.get(market_id, {})
            total += sum(
                abs(v) for v in (positions.values() if isinstance(positions, dict) else [])
            )
        return total

    def _make_trade_and_log_error(
        self, signal: Signal, error_msg: str, trades: list[Trade]
    ) -> None:
        """Registra un trade fallido."""
        trade = self._make_trade(signal, "", "error")
        trade.fee_paid = 0.0
        trade.mid_at_entry = 0.0
        self.log_trade(trade)
        trades.append(trade)

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------

    def get_weather_status(self) -> dict[str, Any]:
        """Estado de la estrategia de weather para /status de Telegram."""
        return {
            "enabled": self._enabled,
            "active": self._active,
            "open_positions": len(self._open_positions),
            "signals_generated": self._signals_generated,
            "trades_executed": self._trades_executed,
            "pending_markets": len(self._pending_market_ids),
            "cities": self._city_keys,
            "min_edge": self._min_edge_threshold,
            "max_trade_size": self._max_trade_size,
            "max_allocation": self._max_total_allocation,
        }

    @property
    def scan_interval_min(self) -> int:
        return self._scan_interval_min

    @property
    def is_enabled(self) -> bool:
        return self._enabled
