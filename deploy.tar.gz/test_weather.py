"""Tests para WeatherStrategy y modulo de datos de clima."""

import math
from datetime import date
from unittest.mock import MagicMock, patch

import pytest

from src.data.weather import (
    CITY_ALIASES,
    CITY_CONFIG,
    MONTH_MAP,
    EnsembleForecast,
    _celsius_to_fahrenheit,
)
from src.strategy.weather import WeatherMarket, WeatherStrategy

# ------------------------------------------------------------------
# CITY_CONFIG
# ------------------------------------------------------------------


def test_city_config_has_five_cities():
    assert len(CITY_CONFIG) == 5


def test_city_config_required_keys():
    for key in ("nyc", "chicago", "miami", "los_angeles", "denver"):
        city = CITY_CONFIG[key]
        assert "name" in city
        assert "lat" in city
        assert "lon" in city
        assert "nws_station" in city


def test_city_config_valid_coords():
    for key, city in CITY_CONFIG.items():
        assert -90 <= city["lat"] <= 90, f"{key} lat out of range"
        assert -180 <= city["lon"] <= 180, f"{key} lon out of range"


def test_celsius_to_fahrenheit():
    assert _celsius_to_fahrenheit(0) == 32.0
    assert _celsius_to_fahrenheit(100) == 212.0
    assert math.isclose(_celsius_to_fahrenheit(20), 68.0)
    assert math.isclose(_celsius_to_fahrenheit(-40), -40.0)


# ------------------------------------------------------------------
# EnsembleForecast
# ------------------------------------------------------------------


def make_forecast(highs, lows):
    return EnsembleForecast(
        city_key="nyc",
        city_name="New York City",
        target_date=date(2026, 6, 15),
        member_highs=list(highs),
        member_lows=list(lows),
    )


def test_ensemble_probability_all_above():
    fc = make_forecast([80, 81, 82, 83, 84], [60, 61, 62, 63, 64])
    assert fc.probability_high_above(75) == 1.0
    assert fc.probability_high_below(75) == 0.0


def test_ensemble_probability_all_below():
    fc = make_forecast([80, 81, 82, 83, 84], [60, 61, 62, 63, 64])
    assert fc.probability_high_above(85) == 0.0
    assert fc.probability_high_below(85) == 1.0


def test_ensemble_probability_mixed():
    fc = make_forecast([70, 72, 75, 78, 80], [50, 52, 55, 58, 60])
    assert fc.probability_high_above(75) == 0.4  # 2 de 5
    assert fc.probability_high_below(75) == 0.6


def test_ensemble_probability_low():
    fc = make_forecast([80, 81, 82, 83, 84], [60, 61, 62, 63, 64])
    assert fc.probability_low_above(62) == 0.4  # 63, 64 -> 2/5
    # low < 61: only 60 (1); low <= 61: 60, 61 (2). Below = 1-above(strict >)
    assert fc.probability_low_below(61) == 0.4  # low <= 61: 60, 61 -> 2/5


def test_ensemble_probability_empty_returns_half():
    fc = make_forecast([], [])
    assert fc.probability_high_above(75) == 0.5
    assert fc.probability_low_below(50) == 0.5


def test_ensemble_mean_and_std():
    fc = make_forecast([70, 72, 75, 78, 80], [50, 52, 55, 58, 60])
    assert fc.mean_high == 75.0
    assert fc.num_members == 5
    assert fc.std_high > 0


def test_ensemble_agreement_unanimous():
    # All members equal: median = 92, all others equal, agreement is 50/50
    fc = make_forecast([90, 91, 92, 93, 94], [70, 71, 72, 73, 74])
    assert fc.ensemble_agreement == 0.6  # median 92, 2 above, 2 below -> max(0.4, 0.6)


def test_ensemble_agreement_split():
    fc = make_forecast([70, 72, 75, 78, 80], [50, 52, 55, 58, 60])
    # median = 75, above_median = 2/5 = 0.4, max(0.4, 0.6) = 0.6
    assert fc.ensemble_agreement == 0.6


# ------------------------------------------------------------------
# Market title parsing
# ------------------------------------------------------------------


def test_parse_high_above():
    title = "Will the high temperature in New York exceed 75F on March 5?"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "nyc"
    assert result["threshold_f"] == 75
    assert result["metric"] == "high"
    assert result["direction"] == "above"
    assert result["target_date"].month == 3
    assert result["target_date"].day == 5


def test_parse_high_above_with_degree():
    title = "NYC high temperature above 80F on March 10, 2026"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "nyc"
    assert result["threshold_f"] == 80
    assert result["metric"] == "high"
    assert result["direction"] == "above"
    assert result["target_date"].year == 2026


def test_parse_low_below():
    title = "Will Miami's low be below 65F on March 7?"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "miami"
    assert result["threshold_f"] == 65
    assert result["metric"] == "low"
    assert result["direction"] == "below"


def test_parse_la_alias():
    title = "Temperature in LA above 70F on 3/5/2026"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "los_angeles"
    assert result["threshold_f"] == 70


def test_parse_denver():
    title = "Temperature in Denver above 70F on March 5, 2026"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "denver"
    assert result["threshold_f"] == 70


def test_parse_chicago_high_over():
    title = "Chicago daily high over 60F on March 3"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "chicago"
    assert result["threshold_f"] == 60
    assert result["metric"] == "high"
    assert result["direction"] == "above"


def test_parse_low_above():
    title = "Will Chicago low temperature be above 40F on March 10?"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["city_key"] == "chicago"
    assert result["threshold_f"] == 40
    assert result["metric"] == "low"
    assert result["direction"] == "above"


def test_parse_with_degrees_keyword():
    title = "Will the high in NYC reach 80 degrees on March 15?"
    result = WeatherStrategy._parse_weather_market_title(title)
    assert result is not None
    assert result["threshold_f"] == 80


def test_parse_non_weather_returns_none():
    assert WeatherStrategy._parse_weather_market_title("Will bitcoin reach 100k?") is None


def test_parse_unknown_city_returns_none():
    assert WeatherStrategy._parse_weather_market_title("Temperature in Tokyo above 70F on March 5") is None


# ------------------------------------------------------------------
# Date extraction
# ------------------------------------------------------------------


def test_extract_date_full():
    d = WeatherStrategy._extract_date("march 5 2026")
    assert d == date(2026, 3, 5)


def test_extract_date_with_comma():
    d = WeatherStrategy._extract_date("march 5, 2026")
    assert d == date(2026, 3, 5)


def test_extract_date_abbreviated():
    d = WeatherStrategy._extract_date("mar 15 2026")
    assert d == date(2026, 3, 15)


def test_extract_date_numeric():
    d = WeatherStrategy._extract_date("3/5/2026")
    assert d == date(2026, 3, 5)


def test_extract_date_numeric_short():
    d = WeatherStrategy._extract_date("03/05")
    today = date.today()
    assert d == date(today.year, 3, 5)


def test_extract_date_no_date():
    assert WeatherStrategy._extract_date("no date here") is None


# ------------------------------------------------------------------
# WeatherMarket dataclass
# ------------------------------------------------------------------


def test_weather_market_creation():
    wm = WeatherMarket(
        slug="test-slug",
        market_id="test-id-123",
        platform="polymarket",
        title="Will the high in NYC exceed 75F on March 5?",
        city_key="nyc",
        city_name="New York City",
        target_date=date(2026, 3, 5),
        threshold_f=75.0,
        metric="high",
        direction="above",
        yes_price=0.55,
        no_price=0.45,
    )
    assert wm.city_key == "nyc"
    assert wm.threshold_f == 75.0
    assert wm.metric == "high"
    assert wm.direction == "above"


# ------------------------------------------------------------------
# WeatherStrategy initialization
# ------------------------------------------------------------------


class DummyClient:
    def __init__(self):
        self.paper_mode = True

    def get_positions(self):
        return []

    def place_limit_order(self, token_id, price, size, side, post_only=False):
        return {
            "id": f"dummy_order_{token_id[:8]}",
            "status": "filled_paper",
            "order_id": f"dummy_order_{token_id[:8]}",
        }

    def cancel_order(self, order_id):
        return True


@pytest.fixture
def weather_strategy():
    config = {
        "weather": {
            "enabled": True,
            "scan_interval_minutes": 5,
            "min_edge_threshold": 0.08,
            "max_entry_price": 0.70,
            "max_trade_size_usdc": 25.0,
            "max_total_allocation": 50.0,
            "max_trades_per_scan": 3,
            "kelly_fraction": 0.15,
            "cities": "nyc,chicago,miami,los_angeles,denver",
        },
        "loss_reserve_usdc": 20.0,
        "markets": {},
        "risk": {},
    }
    return WeatherStrategy(DummyClient(), config)


def test_strategy_name_is_weather(weather_strategy):
    assert weather_strategy.name == "weather"


def test_should_act_returns_false(weather_strategy):
    assert weather_strategy.should_act({}) is False


def test_evaluate_returns_empty(weather_strategy):
    assert weather_strategy.evaluate({}) == []


def test_weather_strategy_cities_parsed(weather_strategy):
    assert "nyc" in weather_strategy._city_keys
    assert "chicago" in weather_strategy._city_keys
    assert "miami" in weather_strategy._city_keys
    assert "los_angeles" in weather_strategy._city_keys
    assert "denver" in weather_strategy._city_keys
    assert len(weather_strategy._city_keys) == 5


def test_weather_strategy_disabled_by_default():
    config = {
        "weather": {
            "enabled": False,
            "cities": "nyc",
        },
        "markets": {},
        "risk": {},
    }
    ws = WeatherStrategy(DummyClient(), config)
    assert ws.is_enabled is False


def test_weather_strategy_pause_resume(weather_strategy):
    weather_strategy.pause()
    assert not weather_strategy.is_active
    weather_strategy.resume()
    assert weather_strategy.is_active


def test_get_weather_status(weather_strategy):
    status = weather_strategy.get_weather_status()
    assert "enabled" in status
    assert "open_positions" in status
    assert "signals_generated" in status
    assert "cities" in status
    assert "min_edge" in status


def test_calc_shares(weather_strategy):
    shares = weather_strategy._calc_shares(25.0, 0.50)
    assert shares == 50.0
    shares = weather_strategy._calc_shares(25.0, 0.75)
    assert shares == 33.0  # floor(25/0.75=33.33)
    assert weather_strategy._calc_shares(25.0, 0.0) == 0.0
    assert weather_strategy._calc_shares(25.0, 1.0) == 0.0


# ------------------------------------------------------------------
# Edge calculation (via _generate_signal logic)
# ------------------------------------------------------------------


def test_edge_up_vs_down():
    model_prob = 0.60
    market_prob = 0.50
    up_edge = model_prob - market_prob
    down_edge = (1.0 - model_prob) - (1.0 - market_prob)
    # up_edge = 0.10, down_edge = -0.10
    assert abs(up_edge - 0.10) < 0.001
    assert abs(down_edge - (-0.10)) < 0.001


def test_edge_chooses_bigger():
    model_prob = 0.70
    market_prob = 0.50
    up_edge = model_prob - market_prob  # 0.20
    down_edge = (1.0 - model_prob) - (1.0 - market_prob)  # -0.20
    assert up_edge > down_edge
    assert abs(up_edge) >= abs(down_edge)


def test_kelly_zero_when_no_edge():
    win_prob = 0.50
    odds = (1.0 - 0.50) / 0.50  # 1.0
    lose_prob = 0.50
    kelly = (win_prob * odds - lose_prob) / odds
    assert kelly == 0.0


# ------------------------------------------------------------------
# CITY_ALIASES
# ------------------------------------------------------------------


def test_city_aliases_mapping():
    assert CITY_ALIASES["new york"] == "nyc"
    assert CITY_ALIASES["nyc"] == "nyc"
    assert CITY_ALIASES["new york city"] == "nyc"
    assert CITY_ALIASES["la"] == "los_angeles"
    assert CITY_ALIASES["los angeles"] == "los_angeles"


# ------------------------------------------------------------------
# MONTH_MAP
# ------------------------------------------------------------------


def test_month_map():
    assert MONTH_MAP["january"] == 1
    assert MONTH_MAP["jan"] == 1
    assert MONTH_MAP["december"] == 12
    assert MONTH_MAP["dec"] == 12
