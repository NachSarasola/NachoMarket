"""Safe Compounder — estrategia matematica NO-side sin IA.

Apuesta solo al lado NO en mercados donde YES esta barato
y el NO tiene alta probabilidad de resolverse a favor.

Condiciones de entrada:
  - YES last_price en [min_yes, max_yes] (default [0.01, 0.20])
  - NO best_ask >= min_no_ask (default 0.80)
  - Edge = |estimated_true_prob - NO_ask| > min_edge (default 0.03)
  - max P% del capital por posicion (default 10%)
  - Post Only para fees cero
  - Excluye sports, entertainment, awards
  - Excluye titulos con keywords prohibidas

Kelly fraccional para sizing (Half-Kelly).
"""

from __future__ import annotations

import logging
import math
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from src.risk.position_sizer import kelly_fraction as _kelly_fraction
from src.strategy.base import BaseStrategy, Signal, Trade

if TYPE_CHECKING:
    from src.polymarket.client import PolymarketClient
    from src.risk.circuit_breaker import CircuitBreaker
    from src.risk.edge_filter import EdgeFilter
    from src.risk.inventory import InventoryManager
    from src.risk.position_sizer import PositionSizer
    from src.polymarket.market_filter import MarketFilter
    from src.strategy.category_scorer import CategoryScorer

logger = logging.getLogger("nachomarket.strategy.safe_compounder")


class SafeCompounderStrategy(BaseStrategy):
    """Apuesta matematica al NO, sin depender de IA."""

    def __init__(
        self,
        client: PolymarketClient,
        config: dict[str, Any],
        circuit_breaker: CircuitBreaker | None = None,
        position_sizer: PositionSizer | None = None,
        market_filter: MarketFilter | None = None,
        inventory: InventoryManager | None = None,
        category_scorer: CategoryScorer | None = None,
        edge_filter: EdgeFilter | None = None,
    ) -> None:
        super().__init__("safe_compounder", client, config)
        scfg = config.get("safe_compounder", {})

        self._circuit_breaker = circuit_breaker
        self._position_sizer = position_sizer
        self._market_filter = market_filter
        self._inventory = inventory
        self._category_scorer = category_scorer
        self._edge_filter = edge_filter

        self._min_yes_price = float(scfg.get("min_yes_price", 0.01))
        self._max_yes_price = float(scfg.get("max_yes_price", 0.20))
        self._min_no_ask = float(scfg.get("min_no_ask", 0.80))
        self._min_edge = float(scfg.get("min_edge", 0.03))
        self._max_position_pct = float(scfg.get("max_position_pct", 0.10))
        self._kelly_fraction = float(scfg.get("kelly_fraction", 0.25))
        self._min_order_usdc = float(scfg.get("min_order_usdc", 1.0))
        self._skip_categories: set[str] = set(
            scfg.get("skip_categories", ["sports", "entertainment", "awards"])
        )
        self._skip_keywords: list[str] = scfg.get("skip_keywords", ["mention"])
        self._top_n = int(scfg.get("top_n_candidates", 200))
        self._refresh_sec = float(scfg.get("refresh_interval_sec", 300))

        self._last_eval: dict[str, float] = {}
        self._active_positions: dict[str, dict[str, Any]] = {}

    # --- BaseStrategy interface ---

    def should_act(self, market_data: dict[str, Any]) -> bool:
        """Gate rapido: filtros de categoria, keywords, precios y edge."""
        cid = market_data.get("condition_id", "")

        if self._circuit_breaker is not None and self._circuit_breaker.is_triggered():
            return False

        if self._market_filter is not None and self._market_filter.is_banned(market_data):
            return False

        category = str(market_data.get("category", "")).lower()
        if self._category_scorer is not None and self._category_scorer.is_blocked(category):
            return False

        if category in self._skip_categories:
            return False

        question = str(market_data.get("question", "")).lower()
        for kw in self._skip_keywords:
            if kw in question:
                return False

        return True

    def evaluate(self, market_data: dict[str, Any]) -> list[Signal]:
        """Calcula edge y genera senal BUY NO si las condiciones se cumplen."""
        cid = market_data.get("condition_id", "")
        tokens = market_data.get("tokens", [])
        if len(tokens) < 2:
            return []

        mid_price = float(market_data.get("mid_price", 0.0) or 0.0)
        if mid_price <= 0:
            return []

        # Identificar token YES (outcome con precio mas bajo = YES)
        yes_token = self._find_yes_token(tokens)
        no_token = self._find_no_token(tokens, yes_token)
        if yes_token is None or no_token is None:
            return []

        yes_price = float(yes_token.get("price", 0.0) or 0.0)
        if yes_price <= 0:
            yes_price = mid_price

        if yes_price < self._min_yes_price or yes_price > self._max_yes_price:
            return []

        no_ask = self._get_no_ask(market_data, no_token)
        if no_ask is None or no_ask < self._min_no_ask:
            return []

        estimated_true_prob = self._estimate_true_prob(yes_price, market_data)
        edge = estimated_true_prob - no_ask

        if edge < self._min_edge:
            return []

        confidence = self._calc_confidence(yes_price, no_ask, edge)
        if confidence < 0.40:
            return []

        if self._edge_filter is not None:
            passes, _ = self._edge_filter.has_sufficient_edge(
                estimated_true_prob, no_ask, confidence
            )
            if not passes:
                return []

        size = self._calc_size(market_data, yes_price)
        if size <= 0:
            return []

        buy_price = no_ask - 0.01
        buy_price = max(0.01, round(buy_price, 4))

        no_tid = no_token.get("token_id", "")
        if not no_tid:
            return []

        signal = Signal(
            market_id=cid,
            token_id=no_tid,
            side="BUY",
            price=buy_price,
            size=size,
            confidence=confidence,
            strategy_name=self.name,
            metadata={
                "estimated_prob": estimated_true_prob,
                "edge": edge,
                "yes_price": yes_price,
                "no_ask": no_ask,
            },
        )
        return [signal]

    def execute(self, signals: list[Signal]) -> list[Trade]:
        """Coloca ordenes Post Only BUY NO."""
        trades: list[Trade] = []
        for sig in signals:
            try:
                result = self._client.place_limit_order(
                    token_id=sig.token_id,
                    side=sig.side,
                    price=sig.price,
                    size=sig.size,
                    post_only=True,
                )
                trade = self._make_trade(sig, result.get("order_id", ""), result.get("status", "error"))
                trades.append(trade)
                self.log_trade(trade)
                logger.info(
                    "SafeCompounder: %s %s %s size=%s @ %s → %s",
                    sig.market_id[:10], sig.side, sig.token_id[:8],
                    sig.size, sig.price, trade.status,
                )
            except Exception:
                logger.exception("SafeCompounder: error colocando orden %s", sig.token_id[:8])
        return trades

    # --- Internal helpers ---

    @staticmethod
    def _find_yes_token(tokens: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Encuentra el token YES: el de precio mas bajo en binarios."""
        if len(tokens) < 2:
            return tokens[0] if tokens else None
        t0 = tokens[0]
        t1 = tokens[1]
        p0 = float(t0.get("price", 0.0) or 0.0)
        p1 = float(t1.get("price", 0.0) or 0.0)
        return t0 if p0 <= p1 else t1

    @staticmethod
    def _find_no_token(
        tokens: list[dict[str, Any]], yes_token: dict[str, Any] | None
    ) -> dict[str, Any] | None:
        if yes_token is None or len(tokens) < 2:
            return None
        for t in tokens:
            if t.get("token_id") != yes_token.get("token_id"):
                return t
        return None

    def _get_no_ask(
        self, market_data: dict[str, Any], no_token: dict[str, Any]
    ) -> float | None:
        """Obtiene el best ask del token NO."""
        no_tid = no_token.get("token_id", "")
        orderbook = market_data.get("orderbook", {})
        if no_tid and no_tid in orderbook:
            ob = orderbook[no_tid]
            asks = ob.get("asks", []) if isinstance(ob, dict) else getattr(ob, "asks", [])
            if asks:
                return float(asks[0][0] if isinstance(asks[0], (list, tuple)) else asks[0].get("price", 0))
        # Fallback: estimar NO ask como 1 - YES bid
        yes_token = self._find_yes_token(market_data.get("tokens", []))
        if yes_token:
            yes_tid = yes_token.get("token_id", "")
            ob = orderbook.get(yes_tid, {}) if isinstance(orderbook, dict) else {}
            bids = ob.get("bids", []) if isinstance(ob, dict) else []
            if bids:
                yes_bid = float(bids[0][0] if isinstance(bids[0], (list, tuple)) else bids[0].get("price", 0))
                return 1.0 - yes_bid
        return None

    def _estimate_true_prob(
        self, yes_price: float, market_data: dict[str, Any]
    ) -> float:
        """Estima probabilidad real de resolucion YES.

        Ajusta el precio de mercado por decay temporal:
        Mercados con poco tiempo restante tienen precios de YES
        que subestiman la probabilidad real.
        """
        end_date = market_data.get("end_date", "")
        if not end_date:
            return 1.0 - yes_price

        try:
            if end_date.endswith("Z"):
                end_date = end_date[:-1] + "+00:00"
            end_dt = datetime.fromisoformat(end_date)
            now = datetime.now(timezone.utc)
            hours_left = (end_dt - now).total_seconds() / 3600.0
        except (ValueError, TypeError):
            return 1.0 - yes_price

        if hours_left <= 0:
            return 1.0 - yes_price

        # Decay factor: mas tiempo = mas incertidumbre = YES mas sobrevalorado
        # En 1 hora: factor ~0.02; en 30 dias: factor ~0.15
        decay_factor = min(0.20, 1.0 / (hours_left + 1.0))
        adjusted_yes = yes_price / (1.0 - decay_factor)
        adjusted_yes = min(0.99, max(0.01, adjusted_yes))
        return 1.0 - adjusted_yes

    def _calc_confidence(self, yes_price: float, no_ask: float, edge: float) -> float:
        """Confianza basada en edge, precio YES y no_ask."""
        base = 0.50
        edge_boost = min(0.30, edge * 3.0)
        yes_boost = min(0.10, (self._max_yes_price - yes_price) * 0.5)
        ask_boost = min(0.10, (no_ask - self._min_no_ask) * 0.5)
        return min(0.95, base + edge_boost + yes_boost + ask_boost)

    def _calc_size(self, market_data: dict[str, Any], yes_price: float) -> float:
        """Calcula tamanio usando Kelly fraccional."""
        capital = float(market_data.get("available_cash", 50.0))
        max_by_pct = capital * self._max_position_pct

        no_ask = 1.0 - yes_price
        kf = _kelly_fraction(
            estimated_prob=no_ask,
            market_price=no_ask - 0.01,
            kelly_multiplier=self._kelly_fraction,
        )
        if kf <= 0:
            kf = 0.01
        kelly_size = capital * kf

        size = min(kelly_size, max_by_pct)
        size = math.floor(size * 100) / 100.0
        if size < self._min_order_usdc:
            return 0.0
        return size
